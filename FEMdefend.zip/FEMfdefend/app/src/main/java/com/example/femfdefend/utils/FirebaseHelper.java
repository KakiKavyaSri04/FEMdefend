package com.example.femfdefend.utils;

import com.example.femfdefend.models.EmergencyContact;
import com.example.femfdefend.models.User;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class FirebaseHelper {
    private static final String USERS_REF = "users";
    private static final String EMERGENCY_CONTACTS_REF = "emergency_contacts";
    
    private final FirebaseAuth auth;
    private final FirebaseFirestore db;
    private final CollectionReference usersRef;
    
    private static FirebaseHelper instance;
    
    private FirebaseHelper() {
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        usersRef = db.collection(USERS_REF);
    }
    
    public static FirebaseHelper getInstance() {
        if (instance == null) {
            instance = new FirebaseHelper();
        }
        return instance;
    }
    
    public FirebaseAuth getAuth() {
        return auth;
    }
    
    public FirebaseUser getCurrentUser() {
        return auth.getCurrentUser();
    }
    
    public String getCurrentUserId() {
        FirebaseUser user = getCurrentUser();
        return user != null ? user.getUid() : null;
    }
    
    public CollectionReference getUsersRef() {
        return usersRef;
    }
    
    public DocumentReference getCurrentUserRef() {
        String userId = getCurrentUserId();
        return userId != null ? usersRef.document(userId) : null;
    }
    
    public Task<Void> saveUser(User user) {
        return getCurrentUserRef().set(user);
    }
    
    public Task<Void> updateUserProfile(User user) {
        return getCurrentUserRef().set(user);
    }
    
    public CollectionReference getEmergencyContactsRef() {
        return getCurrentUserRef().collection(EMERGENCY_CONTACTS_REF);
    }
    
    public Task<Void> addEmergencyContact(EmergencyContact contact) {
        return getEmergencyContactsRef().document(contact.getId()).set(contact);
    }
    
    public Task<Void> removeEmergencyContact(String contactId) {
        return getEmergencyContactsRef().document(contactId).delete();
    }
    
    public Task<Void> updateEmergencyContact(EmergencyContact contact) {
        return getEmergencyContactsRef().document(contact.getId()).set(contact);
    }
    
    public void signOut() {
        auth.signOut();
    }

    public DatabaseReference getUserProfile(String userId) {
        return FirebaseDatabase.getInstance().getReference("users").child(userId);
    }

    public Task<Void> updateUserProfile(String fullName, String phone) {
        DocumentReference userRef = getCurrentUserRef();
        if (userRef != null) {
            Map<String, Object> updates = new HashMap<>();
            updates.put("fullName", fullName);
            updates.put("phone", phone);
            return userRef.update(updates);
        }
        return null;
    }

    public DocumentReference getUserDocument(String userId) {
        return db.collection(USERS_REF).document(userId);
    }
} 