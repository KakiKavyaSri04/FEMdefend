package com.example.femfdefend;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.femfdefend.databinding.ActivityLiveTrackingBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.example.femfdefend.utils.FirebaseHelper;

public class LiveTrackingActivity extends AppCompatActivity implements OnMapReadyCallback {
    private ActivityLiveTrackingBinding binding;
    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private boolean isTracking = false;
    private FirebaseHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLiveTrackingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.live_tracking);
        }

        // Initialize location services
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Set up Google Maps
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        binding.btnStartTracking.setOnClickListener(v -> toggleTracking());
        binding.btnFindSafeRoute.setOnClickListener(v -> findSafeRoute());

        // Handle back button press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // If tracking is active, show confirmation dialog
                if (isTracking) {
                    showStopTrackingDialog();
                } else {
                    finish();
                }
            }
        });

        helper = FirebaseHelper.getInstance();
        // Get emergency contacts for location sharing
        helper.getEmergencyContactsRef().addValueEventListener(...);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        checkLocationPermission();
    }

    private void checkLocationPermission() {
        Dexter.withContext(this)
                .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                .withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse response) {
                        startLocationUpdates();
                    }

                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse response) {
                        Toast.makeText(LiveTrackingActivity.this,
                                R.string.permission_location_rationale,
                                Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();
    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        
        mMap.setMyLocationEnabled(true);
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 15));
            }
        });
    }

    private void toggleTracking() {
        isTracking = !isTracking;
        if (isTracking) {
            binding.btnStartTracking.setText(R.string.stop_tracking);
            // TODO: Start location tracking service
            Toast.makeText(this, R.string.success_tracking_started, Toast.LENGTH_SHORT).show();
        } else {
            binding.btnStartTracking.setText(R.string.start_tracking);
            // TODO: Stop location tracking service
            Toast.makeText(this, R.string.success_tracking_stopped, Toast.LENGTH_SHORT).show();
        }
    }

    private void findSafeRoute() {
        // TODO: Implement safe route algorithm
        // This will calculate the safest route based on:
        // - Street lighting
        // - Crime statistics
        // - Population density
        // - Time of day
        Toast.makeText(this, "Finding safest route...", Toast.LENGTH_SHORT).show();
    }

    private void showStopTrackingDialog() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(R.string.stop_tracking_title)
                .setMessage(R.string.stop_tracking_message)
                .setPositiveButton(R.string.stop_tracking, (dialog, which) -> {
                    toggleTracking(); // This will stop tracking
                    finish();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            getOnBackPressedDispatcher().onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
} 