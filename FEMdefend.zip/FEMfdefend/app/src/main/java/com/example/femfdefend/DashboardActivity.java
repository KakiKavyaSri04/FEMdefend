package com.example.femfdefend;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.example.femfdefend.databinding.ActivityDashboardBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.example.femfdefend.utils.FirebaseHelper;

public class DashboardActivity extends AppCompatActivity implements SensorEventListener {
    private ActivityDashboardBinding binding;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private long lastShakeTime;
    private static final float SHAKE_THRESHOLD = 20.0f;
    private static final int MIN_TIME_BETWEEN_SHAKES = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDashboardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        FirebaseAuth auth = FirebaseAuth.getInstance();
        setSupportActionBar(binding.toolbar);

        // Initialize sensor manager for shake detection
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }

        setupClickListeners();

        FirebaseHelper helper = FirebaseHelper.getInstance();
        // Check if user is logged in
        if (helper.getCurrentUser() == null) {
            // Redirect to login
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }
    }

    private void setupClickListeners() {
        binding.cardEmergencyContacts.setOnClickListener(v -> 
            startActivity(new Intent(this, EmergencyContactsActivity.class)));

        binding.cardLaws.setOnClickListener(v -> 
            startActivity(new Intent(this, WomenLawsActivity.class)));

        binding.cardSelfDefense.setOnClickListener(v -> 
            startActivity(new Intent(this, SelfDefenseActivity.class)));

        binding.cardLiveTracking.setOnClickListener(v -> 
            startActivity(new Intent(this, LiveTrackingActivity.class)));

        binding.btnPanic.setOnClickListener(v -> activatePanicMode("Button pressed"));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_theme) {
            toggleTheme();
            return true;
        } else if (item.getItemId() == R.id.action_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
            return true;
        } else if (item.getItemId() == R.id.action_logout) {
            FirebaseHelper helper = FirebaseHelper.getInstance();
            helper.signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void toggleTheme() {
        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }
    }

    private void activatePanicMode(String trigger) {
        // TODO: Implement panic mode activation
        // 1. Get current location
        // 2. Send alerts to emergency contacts
        // 3. Start recording audio/video
        // 4. Call emergency services if configured
        Toast.makeText(this, "Panic mode activated! Trigger: " + trigger, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (accelerometer != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            long currentTime = System.currentTimeMillis();
            if ((currentTime - lastShakeTime) > MIN_TIME_BETWEEN_SHAKES) {
                float x = event.values[0];
                float y = event.values[1];
                float z = event.values[2];
                float acceleration = (float) Math.sqrt(x * x + y * y + z * z) - SensorManager.GRAVITY_EARTH;
                if (acceleration > SHAKE_THRESHOLD) {
                    lastShakeTime = currentTime;
                    activatePanicMode("Device shake detected");
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used
    }
} 